import React from 'react';
import {
  ArrowRight,
  Shield,
  Truck,
  Sparkles,
  Watch,
  Award,
  Layers,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductGrid } from '../components/product/ProductGrid';

export const HomeView: React.FC = () => {
  const { products, navigate } = useStore();

  const featuredWatches = products.filter((p) => p.featured && p.category === 'watches');
  const flagshipProduct = products.find((p) => p.id === 'storium-aethelgard-chrono') || products[0];

  return (
    <div className="w-full flex flex-col bg-[#0B0C0E] text-[#E8E8EC]">
      {/* 1. CINEMATIC HERO SECTION
          Structured specifically to support future Antigravity frame sequence integration
          Semantic ID: #hero-frame-container
      */}
      <section
        id="hero-frame-container"
        data-hero-frames-mount="true"
        data-section="hero"
        className="relative min-h-[92vh] flex items-center justify-center overflow-hidden border-b border-[#262930]"
      >
        {/* Ambient Dark Showroom Lighting Backdrop */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#121316]/80 via-[#0B0C0E]/90 to-[#0B0C0E] z-10" />

        {/* Cinematic Backdrop Image / Frame Anchor Placeholder */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=2000&auto=format&fit=crop"
            alt="STORIUM Luxury Timepiece Backdrop"
            className="w-full h-full object-cover object-center opacity-30 scale-105"
          />
          {/* Subtle Radial Glow in Center */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#D4AF37]/10 via-transparent to-transparent pointer-events-none" />
        </div>

        {/* Hero Content Overlay */}
        <div className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center flex flex-col items-center">
          {/* Brand Tagline Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#181A1F]/80 border border-[#D4AF37]/30 backdrop-blur-md mb-8 shadow-xl">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
            <span className="text-[11px] sm:text-xs uppercase tracking-[0.25em] text-[#E5C378] font-semibold">
              Pakistan&apos;s Futuristic Luxury Showroom
            </span>
          </div>

          {/* Main Statement */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-[#F5F5F7] font-serif-luxury leading-[1.1] max-w-4xl">
            Wear your presence.
          </h1>

          {/* Subtext */}
          <p className="mt-6 text-base sm:text-lg md:text-xl text-[#9Ea2AF] max-w-2xl font-light leading-relaxed">
            Timepieces forged from aerospace titanium, surgical steel, and sapphire crystal. Designed for leaders who command authority without uttering a sound.
          </p>

          {/* Action CTAs */}
          <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => navigate('watches')}
              className="w-full sm:w-auto py-4 px-8 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C5A059] hover:from-[#E5C378] hover:to-[#D4AF37] text-[#0B0C0E] text-xs uppercase tracking-[0.2em] font-bold shadow-[0_10px_30px_rgba(212,175,55,0.25)] hover:shadow-[0_15px_40px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2 group"
            >
              <span>Explore Timepieces</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={() => navigate('shop')}
              className="w-full sm:w-auto py-4 px-8 rounded-xl bg-[#121316]/80 hover:bg-[#181A1F] text-[#E8E8EC] hover:text-[#F5F5F7] text-xs uppercase tracking-[0.2em] font-semibold border border-[#262930] hover:border-[#D4AF37]/50 backdrop-blur-md transition-all"
            >
              Showroom Catalog
            </button>
          </div>

          {/* Micro horological specs bar */}
          <div className="mt-16 pt-8 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center w-full max-w-3xl">
            <div>
              <span className="block text-lg sm:text-xl font-bold text-[#F5F5F7]">316L / Ti</span>
              <span className="text-[10px] uppercase tracking-wider text-[#8E929E]">Aerospace Metallurgy</span>
            </div>
            <div>
              <span className="block text-lg sm:text-xl font-bold text-[#F5F5F7]">Sapphire</span>
              <span className="text-[10px] uppercase tracking-wider text-[#8E929E]">Double-Domed AR Glass</span>
            </div>
            <div>
              <span className="block text-lg sm:text-xl font-bold text-[#F5F5F7]">10 ATM</span>
              <span className="text-[10px] uppercase tracking-wider text-[#8E929E]">Screw-Down Water Res.</span>
            </div>
            <div>
              <span className="block text-lg sm:text-xl font-bold text-[#F5F5F7]">Nationwide</span>
              <span className="text-[10px] uppercase tracking-wider text-[#8E929E]">Express Pakistan COD</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. BRAND INTRODUCTION SECTION
          data-section="brand-introduction"
      */}
      <section data-section="brand-introduction" className="py-24 bg-[#0B0C0E] border-b border-[#262930]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-5 space-y-6">
              <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block">
                The STORIUM Manifesto
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#F5F5F7] font-serif-luxury leading-tight">
                Not an ordinary store. <br />
                A futuristic luxury showroom.
              </h2>
              <p className="text-sm sm:text-base text-[#9Ea2AF] leading-relaxed">
                STORIUM was founded in Pakistan on a singular conviction: the objects you wear and carry are not passive ornaments—they are an extension of your presence and ambition.
              </p>
              <p className="text-sm sm:text-base text-[#9Ea2AF] leading-relaxed">
                By uniting precision Japanese &amp; Swiss mechanical movements with futuristic industrial silhouettes and direct showroom pricing, we bridge the chasm between unattainable Swiss luxury and mass-market disposable watches.
              </p>

              <div className="pt-4 flex items-center gap-6">
                <div>
                  <span className="block text-2xl font-bold text-[#D4AF37] font-serif-luxury">100%</span>
                  <span className="text-xs text-[#8E929E]">Original &amp; Guaranteed</span>
                </div>
                <div className="w-px h-10 bg-[#262930]" />
                <div>
                  <span className="block text-2xl font-bold text-[#D4AF37] font-serif-luxury">2 Years</span>
                  <span className="text-xs text-[#8E929E]">Movement Warranty</span>
                </div>
                <div className="w-px h-10 bg-[#262930]" />
                <div>
                  <span className="block text-2xl font-bold text-[#D4AF37] font-serif-luxury">7 Days</span>
                  <span className="text-xs text-[#8E929E]">Hassle-Free Inspection</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 relative">
              <div className="relative rounded-2xl overflow-hidden bg-[#121316] border border-[#262930] aspect-[16/10] group">
                <img
                  src="https://images.unsplash.com/photo-1547996160-71dfa63582b9?q=80&w=1400&auto=format&fit=crop"
                  alt="STORIUM Horology Craftsmanship"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-mono">
                      EXHIBITION BENCH
                    </span>
                    <h3 className="text-lg font-bold text-[#F5F5F7]">
                      Precision Micro-Engineering
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigate('about')}
                    className="p-3 rounded-full bg-[#181A1F]/90 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0B0C0E] border border-white/10 backdrop-blur-md transition-all"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED WATCHES SHOWCASE
          Rendered through the Reusable ProductGrid component (Automatic animations)
          data-section="featured-watches"
      */}
      <section data-section="featured-watches" className="py-24 bg-[#121316] border-b border-[#262930]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4">
            <div>
              <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-2">
                Flagship Horology
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#F5F5F7] font-serif-luxury">
                Curated Showroom Timepieces
              </h2>
            </div>

            <button
              type="button"
              onClick={() => navigate('watches')}
              className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] font-semibold text-[#D4AF37] hover:text-[#E5C378] transition-colors"
            >
              <span>View All Watches ({products.filter((p) => p.category === 'watches').length})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Automatic Product Animation Grid */}
          <ProductGrid products={featuredWatches} columns="4" />
        </div>
      </section>

      {/* 4. PREMIUM PRODUCT SPOTLIGHT
          Spotlight on Flagship Obsidian Stealth
          data-section="product-showcase"
      */}
      <section data-section="product-showcase" className="py-24 bg-[#0B0C0E] border-b border-[#262930]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 sm:p-12 lg:p-16 rounded-3xl bg-gradient-to-br from-[#121316] to-[#181A1F] border border-[#262930] shadow-2xl relative overflow-hidden">
            {/* Ambient gold glow */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
              {/* Product Image Stage */}
              <div className="lg:col-span-6 flex justify-center">
                <div
                  onClick={() => navigate('product', { slug: flagshipProduct.slug })}
                  className="relative max-w-md w-full aspect-square rounded-2xl overflow-hidden bg-[#0B0C0E] border border-[#D4AF37]/20 cursor-pointer group shadow-2xl"
                >
                  <img
                    src={flagshipProduct.thumbnail}
                    alt={flagshipProduct.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E]/70 via-transparent to-transparent pointer-events-none" />
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-[#E8E8EC]">
                    <span className="px-2.5 py-1 rounded bg-[#D4AF37] text-[#0B0C0E] font-bold uppercase tracking-wider text-[10px]">
                      Flagship Masterpiece
                    </span>
                    <span className="text-[#D4AF37] font-semibold">Click to Inspect &rarr;</span>
                  </div>
                </div>
              </div>

              {/* Technical Blueprint Callouts */}
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-2">
                    Showroom Spotlight
                  </span>
                  <h3 className="text-2xl sm:text-4xl font-bold text-[#F5F5F7] font-serif-luxury">
                    {flagshipProduct.name}
                  </h3>
                  <p className="mt-3 text-sm text-[#9Ea2AF] leading-relaxed">
                    {flagshipProduct.description}
                  </p>
                </div>

                {/* Technical highlights list */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-[#0B0C0E] border border-[#262930]">
                    <span className="text-[10px] uppercase tracking-widest text-[#8E929E] block mb-1">
                      Calibre Engine
                    </span>
                    <span className="text-xs font-semibold text-[#F5F5F7]">
                      {flagshipProduct.specifications['Movement'] || 'Hybrid Mecha-Quartz Sweep'}
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0B0C0E] border border-[#262930]">
                    <span className="text-[10px] uppercase tracking-widest text-[#8E929E] block mb-1">
                      Optics
                    </span>
                    <span className="text-xs font-semibold text-[#F5F5F7]">
                      Double-Domed Sapphire Crystal
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0B0C0E] border border-[#262930]">
                    <span className="text-[10px] uppercase tracking-widest text-[#8E929E] block mb-1">
                      Case Metallics
                    </span>
                    <span className="text-xs font-semibold text-[#F5F5F7]">
                      DLC Matte Black 316L Steel
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0B0C0E] border border-[#262930]">
                    <span className="text-[10px] uppercase tracking-widest text-[#8E929E] block mb-1">
                      Water Resistance
                    </span>
                    <span className="text-xs font-semibold text-[#F5F5F7]">
                      10 ATM / 100 Meters Tested
                    </span>
                  </div>
                </div>

                {/* Price and CTAs */}
                <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
                  <div>
                    <span className="text-xs text-[#8E929E] block">Accessible Luxury Price</span>
                    <span className="text-2xl sm:text-3xl font-bold text-[#F5F5F7]">
                      Rs. {(flagshipProduct.salePrice || flagshipProduct.price).toLocaleString()}
                    </span>
                  </div>

                  <div className="flex gap-3 w-full sm:w-auto sm:ml-auto">
                    <button
                      type="button"
                      onClick={() => navigate('product', { slug: flagshipProduct.slug })}
                      className="flex-1 sm:flex-initial py-3.5 px-6 rounded-xl bg-[#D4AF37] hover:bg-[#E5C378] text-[#0B0C0E] text-xs font-bold uppercase tracking-wider transition-all"
                    >
                      Inspect Timepiece
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('checkout')}
                      className="py-3.5 px-6 rounded-xl bg-[#181A1F] hover:bg-[#22252C] text-[#F5F5F7] text-xs font-semibold uppercase tracking-wider border border-[#262930] hover:border-[#D4AF37]/40 transition-all"
                    >
                      Direct Order
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. BRAND PHILOSOPHY SECTION
          "Products you wear and carry should reflect your personality."
          data-section="brand-philosophy"
      */}
      <section data-section="brand-philosophy" className="py-24 bg-[#121316] border-b border-[#262930]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <span className="text-xs uppercase tracking-[0.28em] text-[#D4AF37] font-semibold">
            The Philosophy of Presence
          </span>

          <blockquote className="text-2xl sm:text-4xl md:text-5xl font-serif-luxury font-medium text-[#F5F5F7] leading-tight">
            &ldquo;Products you wear and carry should reflect your personality.&rdquo;
          </blockquote>

          <p className="text-sm sm:text-base text-[#9Ea2AF] leading-relaxed max-w-2xl mx-auto font-light">
            In an era of fleeting fast-fashion and generic digital displays, the mechanical timepiece remains a defiant statement of discipline, composure, and individuality. A STORIUM watch is not merely a tool to measure hours; it is a signature of who you are.
          </p>

          <div className="pt-4 flex justify-center">
            <div className="w-16 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent" />
          </div>
        </div>
      </section>

      {/* 6. SELECTED COLLECTIONS
          Extensible category architecture: Watches & Men's Accessories
          data-section="collections"
      */}
      <section data-section="collections" className="py-24 bg-[#0B0C0E] border-b border-[#262930]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
              Showroom Galleries
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#F5F5F7] font-serif-luxury">
              Selected Collections
            </h2>
            <p className="text-xs sm:text-sm text-[#8E929E]">
              Designed around lifestyle archetypes—from high-velocity chronographs to open skeleton complications and titanium EDC accoutrements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Collection 1: Chronograph */}
            <div
              onClick={() => navigate('watches')}
              className="group relative h-[420px] rounded-2xl overflow-hidden bg-[#121316] border border-[#262930] hover:border-[#D4AF37]/40 cursor-pointer transition-all duration-300 shadow-xl"
            >
              <img
                src="https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1200&auto=format&fit=crop"
                alt="Chrono Series"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-[#0B0C0E]/40 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-mono block mb-1">
                  COLLECTION 01
                </span>
                <h3 className="text-xl font-bold text-[#F5F5F7] font-serif-luxury">
                  The Chronograph Series
                </h3>
                <p className="text-xs text-[#9Ea2AF] mt-1 line-clamp-2">
                  High-speed dual sub-dial tachymeters engineered for racing precision.
                </p>
                <div className="mt-3 flex items-center gap-1 text-xs text-[#D4AF37] font-semibold uppercase tracking-wider">
                  <span>Explore Series</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>

            {/* Collection 2: Automatic Skeleton */}
            <div
              onClick={() => navigate('watches')}
              className="group relative h-[420px] rounded-2xl overflow-hidden bg-[#121316] border border-[#262930] hover:border-[#D4AF37]/40 cursor-pointer transition-all duration-300 shadow-xl"
            >
              <img
                src="https://images.unsplash.com/photo-1547996160-71dfa63582b9?q=80&w=1200&auto=format&fit=crop"
                alt="Automatic Skeleton"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-[#0B0C0E]/40 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-mono block mb-1">
                  COLLECTION 02
                </span>
                <h3 className="text-xl font-bold text-[#F5F5F7] font-serif-luxury">
                  Automatic Skeleton
                </h3>
                <p className="text-xs text-[#9Ea2AF] mt-1 line-clamp-2">
                  Open-worked mechanics exposing balance wheels and rotor artistry.
                </p>
                <div className="mt-3 flex items-center gap-1 text-xs text-[#D4AF37] font-semibold uppercase tracking-wider">
                  <span>Explore Series</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>

            {/* Collection 3: Men's Accessories (Scalable Category) */}
            <div
              onClick={() => navigate('shop', { category: 'mens-accessories' })}
              className="group relative h-[420px] rounded-2xl overflow-hidden bg-[#121316] border border-[#262930] hover:border-[#D4AF37]/40 cursor-pointer transition-all duration-300 shadow-xl"
            >
              <img
                src="https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=1200&auto=format&fit=crop"
                alt="Men's Accoutrements"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-[#0B0C0E]/40 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-mono block mb-1">
                  COLLECTION 03 &bull; NEW
                </span>
                <h3 className="text-xl font-bold text-[#F5F5F7] font-serif-luxury">
                  Men&apos;s Accoutrements
                </h3>
                <p className="text-xs text-[#9Ea2AF] mt-1 line-clamp-2">
                  CNC-milled titanium RFID cardholders, meteorite cufflinks, and executive accents.
                </p>
                <div className="mt-3 flex items-center gap-1 text-xs text-[#D4AF37] font-semibold uppercase tracking-wider">
                  <span>Explore Accoutrements</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. TRUST / SHIPPING / PAYMENT INFO
          Tailored to Pakistan nationwide luxury service
          data-section="trust-badges"
      */}
      <section data-section="trust-badges" className="py-20 bg-[#121316] border-b border-[#262930]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-[#0B0C0E] border border-[#262930] space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#F5F5F7]">
                Pakistan Nationwide Courier
              </h3>
              <p className="text-xs text-[#8E929E] leading-relaxed">
                We partner with premier express logistics to deliver insured parcels to Karachi, Lahore, Islamabad, Rawalpindi, Peshawar, Quetta, and every corner of Pakistan within 2 to 4 working days.
              </p>
            </div>

            <div className="p-8 rounded-2xl bg-[#0B0C0E] border border-[#262930] space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#F5F5F7]">
                Cash on Delivery &amp; Debit Cards
              </h3>
              <p className="text-xs text-[#8E929E] leading-relaxed">
                Pay with complete peace of mind using Cash on Delivery (COD) upon inspection at your door, or complete instant checkout via Visa &amp; Mastercard debit cards.
              </p>
            </div>

            <div className="p-8 rounded-2xl bg-[#0B0C0E] border border-[#262930] space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#F5F5F7]">
                STORIUM Certificate of Authenticity
              </h3>
              <p className="text-xs text-[#8E929E] leading-relaxed">
                Every timepiece is individually serialized with its laser-engraved caseback SKU and accompanied by our embossed Certificate of Authenticity and 2-Year International Warranty card.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. FINAL CONVERSION SECTION
          data-section="conversion-cta"
      */}
      <section data-section="conversion-cta" className="py-24 bg-[#0B0C0E] relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#D4AF37]/10 via-transparent to-transparent pointer-events-none" />

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
            Step into the Showroom
          </span>

          <h2 className="text-3xl sm:text-5xl font-bold text-[#F5F5F7] font-serif-luxury leading-tight">
            Your wrist speaks before you do.
          </h2>

          <p className="text-sm sm:text-base text-[#9Ea2AF] max-w-xl mx-auto">
            Discover timepieces built to transcend trends. Explore our full collection with complimentary insured delivery across Pakistan.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => navigate('shop')}
              className="w-full sm:w-auto py-4 px-10 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C5A059] hover:from-[#E5C378] hover:to-[#D4AF37] text-[#0B0C0E] text-xs font-bold uppercase tracking-[0.2em] shadow-xl transition-all flex items-center justify-center gap-2"
            >
              <span>Explore All Products</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate('contact')}
              className="w-full sm:w-auto py-4 px-8 rounded-xl bg-[#181A1F] hover:bg-[#20232A] text-[#F5F5F7] text-xs font-semibold uppercase tracking-[0.2em] border border-[#262930] hover:border-[#D4AF37]/40 transition-all"
            >
              Speak with Concierge
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
