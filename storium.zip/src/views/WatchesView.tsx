import React, { useState, useMemo } from 'react';
import { SlidersHorizontal, ArrowUpDown, Check } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductGrid } from '../components/product/ProductGrid';

export const WatchesView: React.FC = () => {
  const { products } = useStore();
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');
  const [maxPrice, setMaxPrice] = useState<number>(70000);

  // Filter for watches
  const watchProducts = useStore().products.filter((p) => p.category === 'watches');

  const tagsList = ['All', 'Chrono', 'Automatic', 'Skeleton', 'Titanium', 'Minimalist', 'Diver', 'GMT'];

  const filteredWatches = useMemo(() => {
    return watchProducts
      .filter((p) => {
        const matchesTag = selectedTag === 'All' || p.tags.includes(selectedTag);
        const effectivePrice = p.salePrice ?? p.price;
        const matchesPrice = effectivePrice <= maxPrice;
        return matchesTag && matchesPrice;
      })
      .sort((a, b) => {
        const priceA = a.salePrice ?? a.price;
        const priceB = b.salePrice ?? b.price;
        if (sortBy === 'price-asc') return priceA - priceB;
        if (sortBy === 'price-desc') return priceB - priceA;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
  }, [watchProducts, selectedTag, sortBy, maxPrice]);

  return (
    <div className="w-full bg-[#0B0C0E] min-h-screen text-[#E8E8EC] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Banner */}
        <div className="py-12 border-b border-[#262930] mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181A1F] border border-[#D4AF37]/30 text-[11px] uppercase tracking-widest text-[#E5C378]">
              <span>Curated Showroom</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-bold font-serif-luxury text-[#F5F5F7]">
              Timepieces Collection
            </h1>
            <p className="text-sm text-[#8E929E] max-w-xl">
              Precision Japanese and Swiss mechanical movements encased in aerospace-grade titanium and 316L surgical steel with scratch-proof sapphire crystal.
            </p>
          </div>

          <div className="text-sm text-[#8E929E] font-mono">
            Showing <span className="text-[#D4AF37] font-bold">{filteredWatches.length}</span> of {watchProducts.length} Timepieces
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-[#121316] border border-[#262930] rounded-2xl p-4 sm:p-6 mb-10 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            {/* Tag Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none max-w-full">
              {tagsList.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setSelectedTag(tag)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs uppercase tracking-wider font-semibold transition-all flex-shrink-0 ${
                    selectedTag === tag
                      ? 'bg-[#D4AF37] text-[#0B0C0E] shadow-md'
                      : 'bg-[#181A1F] text-[#8E929E] hover:text-[#F5F5F7] border border-[#262930]'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-3">
              <span className="text-xs uppercase tracking-wider text-[#8E929E] hidden sm:inline">
                Sort By:
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#181A1F] border border-[#262930] rounded-lg px-3 py-1.5 text-xs text-[#F5F5F7] focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="featured">Showroom Featured</option>
                <option value="newest">Latest Releases</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="pt-3 border-t border-[#262930] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#8E929E]">
            <div className="flex items-center gap-3">
              <span>Filter Max Price:</span>
              <input
                type="range"
                min="20000"
                max="70000"
                step="2500"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-40 sm:w-60 accent-[#D4AF37]"
              />
              <span className="font-bold text-[#F5F5F7]">Rs. {maxPrice.toLocaleString()}</span>
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedTag('All');
                setMaxPrice(70000);
                setSortBy('featured');
              }}
              className="text-xs text-[#D4AF37] hover:underline"
            >
              Reset Filters
            </button>
          </div>
        </div>

        {/* Product Grid with automatic interaction animations */}
        <ProductGrid
          products={filteredWatches}
          emptyMessage="No timepieces match the current filters. Adjust your price range or selection."
          columns="4"
        />
      </div>
    </div>
  );
};
