import React from 'react';
import { Award, Compass, Shield, Watch, ArrowRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const AboutView: React.FC = () => {
  const { navigate } = useStore();

  return (
    <div className="w-full bg-[#0B0C0E] min-h-screen text-[#E8E8EC] py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <span className="text-xs uppercase tracking-[0.28em] text-[#D4AF37] font-semibold">
            Maison STORIUM
          </span>
          <h1 className="text-3xl sm:text-5xl font-bold font-serif-luxury text-[#F5F5F7]">
            Wear Your Presence.
          </h1>
          <p className="text-base sm:text-lg text-[#9Ea2AF] max-w-2xl mx-auto font-light leading-relaxed">
            The story behind Pakistan&apos;s pioneering online luxury showroom for futuristic timepieces and curated men&apos;s accoutrements.
          </p>
        </div>

        {/* Hero Visual */}
        <div className="relative rounded-3xl overflow-hidden border border-[#262930] aspect-[16/9] shadow-2xl">
          <img
            src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1600&auto=format&fit=crop"
            alt="STORIUM Showroom Craftsmanship"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-transparent to-transparent" />
        </div>

        {/* Philosophy */}
        <div className="space-y-6 text-sm sm:text-base text-[#9Ea2AF] leading-relaxed">
          <h2 className="text-2xl font-bold text-[#F5F5F7] font-serif-luxury">
            The Philosophy of Self-Definition
          </h2>
          <p>
            At STORIUM, we reject the notion that luxury must be synonymous with exorbitant markups or antiquated heritage houses. We believe that what you wear and carry is not a passive accessory—it is an external proclamation of your presence, self-discipline, and vision.
          </p>
          <p>
            Founded in Pakistan, STORIUM is built to offer men who demand excellence an accessible gateway into haute horologie. Every timepiece in our catalog is rigorously engineered using materials previously reserved for aerospace and surgical applications: 316L stainless steel, Grade 5 titanium, anti-reflective double-domed sapphire crystals, and precision mechanical escapements.
          </p>
        </div>

        {/* 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          <div className="p-6 rounded-2xl bg-[#121316] border border-[#262930] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
              <Watch className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#F5F5F7]">Precision Horology</h3>
            <p className="text-xs text-[#8E929E] leading-relaxed">
              Equipped with high-beat Japanese and Swiss mechanical calibres regulated for daily precision.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#121316] border border-[#262930] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#F5F5F7]">Indestructible Metals</h3>
            <p className="text-xs text-[#8E929E] leading-relaxed">
              Aerospace DLC coatings, DLC matte finishes, and sapphire crystals impervious to everyday scratches.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#121316] border border-[#262930] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#181A1F] flex items-center justify-center text-[#D4AF37]">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#F5F5F7]">Pakistani Heritage</h3>
            <p className="text-xs text-[#8E929E] leading-relaxed">
              Proudly serving modern gentlemen across Karachi, Lahore, Islamabad, and nationwide with white-glove service.
            </p>
          </div>
        </div>

        {/* Showroom CTA */}
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#121316] to-[#181A1F] border border-[#262930] text-center space-y-6">
          <h3 className="text-2xl font-bold font-serif-luxury text-[#F5F5F7]">
            Discover the Showroom Collection
          </h3>
          <p className="text-xs sm:text-sm text-[#8E929E] max-w-lg mx-auto">
            Experience our flagship automatic chronographs and skeletonized titanium designs.
          </p>
          <button
            type="button"
            onClick={() => navigate('watches')}
            className="py-3.5 px-8 rounded-xl bg-[#D4AF37] hover:bg-[#E5C378] text-[#0B0C0E] text-xs font-bold uppercase tracking-wider shadow-lg transition-all"
          >
            Explore Watches Collection
          </button>
        </div>
      </div>
    </div>
  );
};
