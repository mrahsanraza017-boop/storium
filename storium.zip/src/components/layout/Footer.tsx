import React, { useState } from 'react';
import { ShieldCheck, Truck, Clock, RefreshCw, Mail, ArrowRight, Check } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { PageView } from '../../types';

export const Footer: React.FC = () => {
  const { navigate, addToast } = useStore();
  const [emailInput, setEmailInput] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    setIsSubscribed(true);
    addToast('success', 'Private Access Granted', 'You are now registered for private timepiece drops.');
    setEmailInput('');
  };

  return (
    <footer className="w-full bg-[#0B0C0E] border-t border-[#262930] pt-16 pb-12 text-[#8E929E]">
      {/* 4-Pillar Trust Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-14 border-b border-[#262930]/80">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#121316] border border-[#262930] text-[#D4AF37] flex-shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#F5F5F7] uppercase tracking-wider">
                Nationwide Pakistan Delivery
              </h4>
              <p className="mt-1 text-xs text-[#8E929E] leading-relaxed">
                Insured express delivery to Karachi, Lahore, Islamabad, and 100+ cities across Pakistan.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#121316] border border-[#262930] text-[#D4AF37] flex-shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#F5F5F7] uppercase tracking-wider">
                Cash on Delivery Available
              </h4>
              <p className="mt-1 text-xs text-[#8E929E] leading-relaxed">
                Pay upon arrival at your doorstep or checkout securely with Debit Card.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#121316] border border-[#262930] text-[#D4AF37] flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#F5F5F7] uppercase tracking-wider">
                2-Year STORIUM Guarantee
              </h4>
              <p className="mt-1 text-xs text-[#8E929E] leading-relaxed">
                Comprehensive international movement warranty and sapphire crystal guarantee.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#121316] border border-[#262930] text-[#D4AF37] flex-shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-[#F5F5F7] uppercase tracking-wider">
                7-Day Inspection Return
              </h4>
              <p className="mt-1 text-xs text-[#8E929E] leading-relaxed">
                Complimentary exchange or return policy if unsatisfied with your timepiece.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Directory */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div
              onClick={() => navigate('home')}
              className="cursor-pointer flex items-center gap-1.5"
            >
              <span className="text-2xl font-extrabold tracking-[0.22em] text-[#F5F5F7] font-montserrat uppercase">
                STORIUM
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
            </div>
            <p className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-medium">
              “Wear your presence”
            </p>
            <p className="text-xs text-[#8E929E] leading-relaxed max-w-sm">
              STORIUM is Pakistan&apos;s vanguard online luxury showroom for futuristic timepieces and curated men&apos;s accessories. Combining precision horology, aerospace materials, and accessible luxury.
            </p>

            {/* Newsletter Subscription */}
            <div className="pt-2">
              <span className="block text-xs uppercase tracking-wider font-semibold text-[#F5F5F7] mb-2">
                Private Showroom Registry
              </span>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-sm">
                <div className="relative flex-1">
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="Enter your email"
                    required
                    className="w-full py-2.5 px-3.5 rounded-lg bg-[#121316] border border-[#262930] text-xs text-[#F5F5F7] placeholder-[#626673] focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                </div>
                <button
                  type="submit"
                  className="py-2.5 px-4 rounded-lg bg-[#D4AF37] hover:bg-[#E5C378] text-[#0B0C0E] text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1"
                >
                  {isSubscribed ? <Check className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </button>
              </form>
            </div>
          </div>

          {/* Showroom Collections */}
          <div>
            <h5 className="text-xs uppercase tracking-[0.18em] font-semibold text-[#F5F5F7] mb-4">
              Timepieces
            </h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => navigate('watches')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  All Watches
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('shop')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Chronograph Series
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('shop')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Automatic Mechanical
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('shop')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Skeleton Titanium
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('shop', { category: 'mens-accessories' })}
                  className="hover:text-[#D4AF37] transition-colors flex items-center gap-1"
                >
                  <span>Men&apos;s Accessories</span>
                  <span className="text-[9px] text-[#D4AF37] font-mono">NEW</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Client Concierge */}
          <div>
            <h5 className="text-xs uppercase tracking-[0.18em] font-semibold text-[#F5F5F7] mb-4">
              Concierge
            </h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => navigate('account')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Customer Account
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('wishlist')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Private Wishlist
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('shipping-policy')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Pakistan Shipping Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('return-policy')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  7-Day Returns &amp; Refunds
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('terms')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Terms &amp; Conditions
                </button>
              </li>
            </ul>
          </div>

          {/* Brand & Studio */}
          <div>
            <h5 className="text-xs uppercase tracking-[0.18em] font-semibold text-[#F5F5F7] mb-4">
              Maison
            </h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => navigate('about')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Brand Philosophy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('contact')}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Contact Showroom
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('admin')}
                  className="text-[#D4AF37]/80 hover:text-[#D4AF37] font-mono text-[11px] transition-colors flex items-center gap-1"
                >
                  <span>&bull; Admin Management</span>
                </button>
              </li>
              <li className="pt-2 text-[11px] text-[#626673]">
                <span>Concierge Phone:</span>
                <span className="block text-[#8E929E] font-mono mt-0.5">+92 300 8459201</span>
              </li>
              <li className="text-[11px] text-[#626673]">
                <span>Support Email:</span>
                <span className="block text-[#8E929E] font-mono mt-0.5">concierge@storium.pk</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Copyright & Legal */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-[#262930]/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <p className="text-[#626673]">
          &copy; {new Date().getFullYear()} STORIUM Pakistan. All rights reserved. Registered Luxury Horology Maison.
        </p>
        <div className="flex items-center gap-4 text-[11px] text-[#626673]">
          <button onClick={() => navigate('shipping-policy')} className="hover:text-[#D4AF37]">
            Shipping Policy
          </button>
          <span>&bull;</span>
          <button onClick={() => navigate('return-policy')} className="hover:text-[#D4AF37]">
            Return Policy
          </button>
          <span>&bull;</span>
          <button onClick={() => navigate('terms')} className="hover:text-[#D4AF37]">
            Terms of Service
          </button>
        </div>
      </div>
    </footer>
  );
};
