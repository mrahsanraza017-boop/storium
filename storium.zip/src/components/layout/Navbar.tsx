import React, { useState } from 'react';
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Menu,
  X,
  ShieldAlert,
  Compass,
  Watch,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { PageView } from '../../types';

export const Navbar: React.FC = () => {
  const {
    currentPage,
    navigate,
    cartCount,
    wishlist,
    openCartDrawer,
    openSearch,
    currentUser,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; page: PageView; category?: string; badge?: string }[] = [
    { label: 'Showroom', page: 'home' },
    { label: 'Watches', page: 'watches', category: 'watches' },
    { label: 'Shop All', page: 'shop' },
    { label: "Men's Accessories", page: 'shop', category: 'mens-accessories', badge: 'New' },
    { label: 'About', page: 'about' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleNavClick = (page: PageView, category?: string) => {
    navigate(page, { category });
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0C0E]/90 backdrop-blur-xl border-b border-[#262930]/80">
      {/* Top Luxury Announcement Bar (Nationwide Pakistan Delivery & COD) */}
      <div className="bg-[#121316] border-b border-white/5 py-1.5 px-4 text-center">
        <p className="text-[11px] sm:text-xs text-[#9Ea2AF] tracking-widest uppercase font-medium flex items-center justify-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
          <span>Complimentary Express Delivery Nationwide Across Pakistan &bull; Cash on Delivery Available</span>
        </p>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        {/* Mobile menu button */}
        <div className="flex items-center lg:hidden">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#8E929E] hover:text-[#F5F5F7] hover:bg-[#181A1F] transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Brand Logo & Tagline */}
        <div
          onClick={() => handleNavClick('home')}
          className="cursor-pointer flex flex-col items-center lg:items-start select-none group"
        >
          <div className="flex items-center gap-1.5">
            <span className="text-2xl sm:text-3xl font-extrabold tracking-[0.22em] text-[#F5F5F7] font-montserrat uppercase group-hover:text-white transition-colors">
              STORIUM
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
          </div>
          <span className="text-[9px] uppercase tracking-[0.3em] text-[#D4AF37] font-medium -mt-0.5">
            Wear Your Presence
          </span>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => {
            const isActive =
              currentPage === link.page ||
              (currentPage === 'shop' && link.category && link.page === 'shop');

            return (
              <button
                key={link.label}
                type="button"
                onClick={() => handleNavClick(link.page, link.category)}
                className={`relative text-xs uppercase tracking-widest font-semibold transition-all py-1 flex items-center gap-1.5 ${
                  isActive
                    ? 'text-[#F5F5F7]'
                    : 'text-[#8E929E] hover:text-[#E8E8EC]'
                }`}
              >
                <span>{link.label}</span>
                {link.badge && (
                  <span className="px-1.5 py-0.2 text-[9px] uppercase font-bold tracking-wider bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30 rounded">
                    {link.badge}
                  </span>
                )}
                {/* Active Indicator Line */}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#D4AF37] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Actions: Search, Wishlist, Account, Cart, Admin */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Quick Search */}
          <button
            type="button"
            onClick={openSearch}
            className="p-2.5 rounded-full text-[#8E929E] hover:text-[#F5F5F7] hover:bg-[#181A1F] transition-all"
            title="Search Showroom"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Wishlist */}
          <button
            type="button"
            onClick={() => handleNavClick('wishlist')}
            className="relative p-2.5 rounded-full text-[#8E929E] hover:text-[#F5F5F7] hover:bg-[#181A1F] transition-all"
            title="Wishlist"
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-[#D4AF37] text-[#0B0C0E] text-[10px] font-bold flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Customer Account */}
          <button
            type="button"
            onClick={() => handleNavClick('account')}
            className={`p-2.5 rounded-full transition-all ${
              currentUser
                ? 'text-[#D4AF37] hover:bg-[#181A1F]'
                : 'text-[#8E929E] hover:text-[#F5F5F7] hover:bg-[#181A1F]'
            }`}
            title={currentUser ? `Account: ${currentUser.fullName}` : 'Sign In'}
            aria-label="Account"
          >
            <User className="w-5 h-5" />
          </button>

          {/* Shopping Bag / Cart */}
          <button
            type="button"
            onClick={openCartDrawer}
            className="relative p-2.5 rounded-full bg-[#181A1F] text-[#F5F5F7] hover:text-[#D4AF37] border border-[#262930] hover:border-[#D4AF37]/50 transition-all flex items-center gap-2 px-3.5"
            title="Shopping Bag"
            aria-label="Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="hidden sm:inline text-xs uppercase tracking-wider font-semibold">
              Bag
            </span>
            {cartCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#D4AF37] text-[#0B0C0E] text-xs font-bold flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Admin Dashboard Portal Link */}
          <button
            type="button"
            onClick={() => handleNavClick('admin')}
            className="hidden xl:flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-[11px] font-mono tracking-wider uppercase bg-[#181A1F]/60 hover:bg-[#22252C] border border-white/5 text-[#8E929E] hover:text-[#D4AF37] transition-all ml-1"
            title="Admin Showroom Portal"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Admin</span>
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown / Slide-Down */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#121316] border-b border-[#262930] px-4 pt-3 pb-6 space-y-2 shadow-2xl">
          {navLinks.map((link) => (
            <button
              key={link.label}
              type="button"
              onClick={() => handleNavClick(link.page, link.category)}
              className="w-full text-left py-2.5 px-3 rounded-lg text-sm uppercase tracking-wider font-medium text-[#E8E8EC] hover:bg-[#181A1F] hover:text-[#D4AF37] flex items-center justify-between"
            >
              <span>{link.label}</span>
              {link.badge && (
                <span className="px-2 py-0.5 text-[10px] bg-[#D4AF37]/20 text-[#D4AF37] rounded">
                  {link.badge}
                </span>
              )}
            </button>
          ))}

          <div className="pt-4 border-t border-[#262930] flex flex-col gap-2">
            <button
              type="button"
              onClick={() => handleNavClick('admin')}
              className="w-full py-2.5 px-3 rounded-lg text-xs font-mono uppercase tracking-wider bg-[#181A1F] text-[#D4AF37] border border-[#D4AF37]/30 flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Admin Showroom Portal</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
