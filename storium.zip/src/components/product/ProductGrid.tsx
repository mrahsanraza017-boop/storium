import React from 'react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  emptyMessage?: string;
  columns?: '2' | '3' | '4';
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  emptyMessage = 'No timepieces found in this selection.',
  columns = '4',
}) => {
  if (products.length === 0) {
    return (
      <div className="py-16 text-center border border-dashed border-[#262930] rounded-2xl bg-[#121316]/50">
        <p className="text-[#8E929E] text-sm tracking-wide">{emptyMessage}</p>
      </div>
    );
  }

  const colClasses = {
    '2': 'grid-cols-1 sm:grid-cols-2',
    '3': 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    '4': 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4',
  }[columns];

  return (
    <div className={`grid ${colClasses} gap-5 sm:gap-6 lg:gap-7`} data-product-grid>
      {products.map((product) => (
        <div key={product.id} className="h-full">
          <ProductCard product={product} />
        </div>
      ))}
    </div>
  );
};
