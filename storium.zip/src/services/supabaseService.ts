import { supabase, SUPABASE_PROJECT_ID, SUPABASE_URL } from '../lib/supabase';
import { Order, ContactInquiry } from '../types';

export type { ContactInquiry };

export interface SupabaseSyncResult {
  success: boolean;
  data?: any;
  error?: string;
  isTableMissing?: boolean;
  isPolicyError?: boolean;
}

export interface SupabaseHealthStatus {
  connected: boolean;
  ordersTableExists: boolean;
  contactsTableExists: boolean;
  projectId: string;
  url: string;
  checkedAt: string;
  message?: string;
  error?: string;
}

// Ready-to-execute SQL migration script for Supabase SQL Editor
export const SUPABASE_SQL_SCHEMA = `-- ================================================================
-- STORIUM Pakistan: Supabase Database Schema
-- Run this SQL in your Supabase Project SQL Editor
-- Project ID: ${SUPABASE_PROJECT_ID}
-- URL: ${SUPABASE_URL}
-- ================================================================

-- 1. Create orders table for luxury showroom purchases
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    customer_city TEXT NOT NULL,
    customer_address TEXT NOT NULL,
    customer_province TEXT DEFAULT 'Punjab',
    postal_code TEXT,
    notes TEXT,
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    shipping_fee NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    payment_method TEXT NOT NULL DEFAULT 'cod',
    payment_status TEXT NOT NULL DEFAULT 'pending',
    order_status TEXT NOT NULL DEFAULT 'Pending',
    tracking_number TEXT
);

-- 2. Create contacts table for showroom & concierge inquiries
CREATE TABLE IF NOT EXISTS public.contacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    topic TEXT NOT NULL DEFAULT 'Timepiece Inquiries',
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new'
);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

-- 4. Set RLS Policies for Anonymous Public Access (publishable key)
-- Allow visitors to insert new orders
DROP POLICY IF EXISTS "Allow anonymous orders insert" ON public.orders;
CREATE POLICY "Allow anonymous orders insert" 
ON public.orders FOR INSERT 
WITH CHECK (true);

-- Allow reading orders
DROP POLICY IF EXISTS "Allow orders select" ON public.orders;
CREATE POLICY "Allow orders select" 
ON public.orders FOR SELECT 
USING (true);

-- Allow visitors to insert contact inquiries
DROP POLICY IF EXISTS "Allow anonymous contacts insert" ON public.contacts;
CREATE POLICY "Allow anonymous contacts insert" 
ON public.contacts FOR INSERT 
WITH CHECK (true);

-- Allow reading contact inquiries
DROP POLICY IF EXISTS "Allow contacts select" ON public.contacts;
CREATE POLICY "Allow contacts select" 
ON public.contacts FOR SELECT 
USING (true);
`;

/**
 * Save an order to Supabase orders table
 */
export async function saveOrderToSupabase(order: Order): Promise<SupabaseSyncResult> {
  try {
    const payload = {
      order_number: order.orderNumber,
      customer_name: order.customer.fullName,
      customer_email: order.customer.email,
      customer_phone: order.customer.phone,
      customer_city: order.customer.city,
      customer_address: order.customer.address,
      customer_province: order.customer.province || 'Punjab',
      postal_code: order.customer.postalCode || '',
      notes: order.customer.notes || '',
      items: order.items,
      subtotal: order.subtotal,
      shipping_fee: order.shippingFee,
      total: order.total,
      payment_method: order.paymentMethod,
      payment_status: order.paymentStatus,
      order_status: order.orderStatus,
      tracking_number: order.trackingNumber || '',
    };

    const { data, error } = await supabase
      .from('orders')
      .insert([payload])
      .select();

    if (error) {
      console.warn('Supabase save order warning:', error);
      const isTableMissing = error.code === 'PGRST205' || error.message?.includes('not find');
      const isPolicyError = error.code === '42501' || error.message?.includes('row-level security');
      return {
        success: false,
        error: error.message,
        isTableMissing,
        isPolicyError,
      };
    }

    return {
      success: true,
      data,
    };
  } catch (err: any) {
    console.error('Unexpected Supabase order insert error:', err);
    return {
      success: false,
      error: err?.message || 'Network connection failed while reaching Supabase',
    };
  }
}

/**
 * Save contact form inquiry to Supabase
 */
export async function saveContactToSupabase(inquiry: {
  name: string;
  email: string;
  phone?: string;
  topic: string;
  message: string;
}): Promise<SupabaseSyncResult> {
  try {
    const payload = {
      name: inquiry.name,
      email: inquiry.email,
      phone: inquiry.phone || '',
      topic: inquiry.topic || 'General Inquiry',
      message: inquiry.message,
      status: 'new',
    };

    // Try 'contacts' table first
    let { data, error } = await supabase
      .from('contacts')
      .insert([payload])
      .select();

    // If 'contacts' table is not found, fallback to check 'contact_messages'
    if (error && (error.code === 'PGRST205' || error.message?.includes('not find'))) {
      const fallbackResult = await supabase
        .from('contact_messages')
        .insert([payload])
        .select();

      if (!fallbackResult.error) {
        return { success: true, data: fallbackResult.data };
      }
    }

    if (error) {
      console.warn('Supabase save contact warning:', error);
      const isTableMissing = error.code === 'PGRST205' || error.message?.includes('not find');
      const isPolicyError = error.code === '42501' || error.message?.includes('row-level security');
      return {
        success: false,
        error: error.message,
        isTableMissing,
        isPolicyError,
      };
    }

    return {
      success: true,
      data,
    };
  } catch (err: any) {
    console.error('Unexpected Supabase contact insert error:', err);
    return {
      success: false,
      error: err?.message || 'Network connection failed while reaching Supabase',
    };
  }
}

/**
 * Fetch orders stored in Supabase
 */
export async function fetchSupabaseOrders(): Promise<Order[]> {
  try {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) {
      return [];
    }

    return data.map((row: any) => ({
      id: row.id,
      orderNumber: row.order_number,
      date: row.created_at,
      customer: {
        fullName: row.customer_name,
        email: row.customer_email,
        phone: row.customer_phone,
        city: row.customer_city,
        address: row.customer_address,
        province: row.customer_province || 'Punjab',
        postalCode: row.postal_code,
        notes: row.notes,
      },
      items: Array.isArray(row.items) ? row.items : [],
      subtotal: Number(row.subtotal),
      shippingFee: Number(row.shipping_fee),
      total: Number(row.total),
      paymentMethod: row.payment_method,
      paymentStatus: row.payment_status,
      orderStatus: row.order_status,
      trackingNumber: row.tracking_number,
      supabaseSynced: true,
    }));
  } catch (err) {
    console.warn('Failed to load orders from Supabase:', err);
    return [];
  }
}

/**
 * Fetch contact submissions stored in Supabase
 */
export async function fetchSupabaseContacts(): Promise<ContactInquiry[]> {
  try {
    const { data, error } = await supabase
      .from('contacts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) {
      return [];
    }

    return data.map((row: any): ContactInquiry => ({
      id: String(row.id || 'inq-' + Math.random().toString(36).substring(2, 9)),
      name: row.name || 'Anonymous Client',
      email: row.email || '',
      phone: row.phone || '',
      topic: row.topic || 'General Inquiry',
      message: row.message || '',
      createdAt: row.created_at || new Date().toISOString(),
      status: (row.status as ContactInquiry['status']) || 'new',
      supabaseSynced: true,
    }));
  } catch (err) {
    console.warn('Failed to load contacts from Supabase:', err);
    return [];
  }
}

/**
 * Verify Supabase connection and table availability
 */
export async function checkSupabaseHealth(): Promise<SupabaseHealthStatus> {
  const result: SupabaseHealthStatus = {
    connected: false,
    ordersTableExists: false,
    contactsTableExists: false,
    projectId: SUPABASE_PROJECT_ID,
    url: SUPABASE_URL,
    checkedAt: new Date().toISOString(),
    message: '',
  };

  try {
    // Check orders table
    const ordersRes = await supabase.from('orders').select('id').limit(1);
    result.ordersTableExists = !ordersRes.error || ordersRes.error.code !== 'PGRST205';

    // Check contacts table
    const contactsRes = await supabase.from('contacts').select('id').limit(1);
    result.contactsTableExists = !contactsRes.error || contactsRes.error.code !== 'PGRST205';

    result.connected = true;
    result.message =
      result.ordersTableExists && result.contactsTableExists
        ? 'Connected: Both orders and contacts tables are active and responding.'
        : 'Supabase reachable: Tables await initialization in SQL Editor.';
  } catch (err: any) {
    result.connected = false;
    result.error = err?.message;
    result.message = 'Connection failed: ' + (err?.message || 'Unknown network error');
  }

  return result;
}

