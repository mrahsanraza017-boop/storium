import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  CartItem,
  Order,
  CustomerUser,
  PageView,
  ContactInquiry,
} from '../types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_ORDERS } from '../data/initialData';
import {
  saveOrderToSupabase,
  saveContactToSupabase,
  fetchSupabaseOrders,
  fetchSupabaseContacts,
  checkSupabaseHealth,
} from '../services/supabaseService';

interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'error';
  title: string;
  message?: string;
}

interface StoreContextType {
  // Navigation
  currentPage: PageView;
  selectedSlug: string | null;
  activeCategoryFilter: string | null;
  navigate: (page: PageView, params?: { slug?: string; category?: string }) => void;

  // Catalog
  products: Product[];
  categories: Category[];
  getProductBySlug: (slug: string) => Product | undefined;
  getProductById: (id: string) => Product | undefined;
  addProduct: (product: Partial<Product>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCategory: (cat: Partial<Category>) => void;

  // Cart
  cart: CartItem[];
  cartCount: number;
  cartSubtotal: number;
  cartShippingFee: number;
  cartTotal: number;
  addToCart: (product: Product, quantity?: number, variant?: Record<string, string>) => void;
  removeFromCart: (productId: string, variantKey?: string) => void;
  updateCartQuantity: (productId: string, quantity: number, variantKey?: string) => void;
  clearCart: () => void;
  isCartDrawerOpen: boolean;
  openCartDrawer: () => void;
  closeCartDrawer: () => void;

  // Wishlist
  wishlist: string[]; // array of product ids
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Orders
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'date'>) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: Order['orderStatus']) => void;
  lastPlacedOrder: Order | null;

  // Concierge / Inquiries
  inquiries: ContactInquiry[];
  submitContactInquiry: (
    inquiryData: Omit<ContactInquiry, 'id' | 'createdAt' | 'status'>
  ) => Promise<{ success: boolean; supabaseSynced: boolean; message?: string }>;

  // Supabase Sync
  isSupabaseSyncing: boolean;
  syncWithSupabase: () => Promise<void>;

  // Customer / Auth
  currentUser: CustomerUser | null;
  loginUser: (email: string, fullName?: string, phone?: string) => void;
  logoutUser: () => void;
  updateUserProfile: (updates: Partial<CustomerUser>) => void;

  // Search
  isSearchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Quick View Modal
  quickViewProduct: Product | null;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;

  // Toast
  toasts: ToastNotification[];
  addToast: (type: 'success' | 'info' | 'error', title: string, message?: string) => void;
  removeToast: (id: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'storium_products_v1',
  CATEGORIES: 'storium_categories_v1',
  CART: 'storium_cart_v1',
  WISHLIST: 'storium_wishlist_v1',
  ORDERS: 'storium_orders_v1',
  INQUIRIES: 'storium_inquiries_v1',
  USER: 'storium_user_v1',
};


export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation State
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string | null>(null);

  // Data State with LocalStorage Persistence
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_CATEGORIES;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CART);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WISHLIST);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_ORDERS;
  });

  const [currentUser, setCurrentUser] = useState<CustomerUser | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      id: 'cust-demo-1',
      fullName: 'Hamza Tariq',
      email: 'hamza.tariq@gmail.com',
      phone: '+92 300 8459201',
      city: 'Lahore',
      address: 'House 42, Sector Y, Phase 5, DHA',
      createdAt: '2025-01-10T12:00:00Z',
    };
  });

  const [inquiries, setInquiries] = useState<ContactInquiry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INQUIRIES);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'inq-sample-1',
        name: 'Taimoor Khan',
        email: 'taimoor.khan@domain.pk',
        phone: '+92 321 9876543',
        topic: 'Timepiece Inquiries',
        message: 'Interested in reserving the Titanium Skeleton Tourbillon. What is the express delivery timeframe for Islamabad?',
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        status: 'new',
        supabaseSynced: true,
      },
    ];
  });

  const [isSupabaseSyncing, setIsSupabaseSyncing] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  // UI state
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(inquiries));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [inquiries]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_KEYS.USER);
      }
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  }, [currentUser]);

  // Sync state with Supabase backend
  const syncWithSupabase = async () => {
    setIsSupabaseSyncing(true);
    try {
      const [remoteOrders, remoteContacts] = await Promise.all([
        fetchSupabaseOrders(),
        fetchSupabaseContacts(),
      ]);

      if (remoteOrders && remoteOrders.length > 0) {
        setOrders((prev) => {
          const map = new Map<string, Order>();
          // Remote Supabase orders take precedence
          remoteOrders.forEach((o) => map.set(o.orderNumber, o));
          // Keep any locally cached orders not yet on Supabase
          prev.forEach((o) => {
            if (!map.has(o.orderNumber)) map.set(o.orderNumber, o);
          });
          return Array.from(map.values());
        });
      }

      if (remoteContacts && remoteContacts.length > 0) {
        setInquiries((prev) => {
          const map = new Map<string, ContactInquiry>();
          remoteContacts.forEach((c) => {
            if (c.id) map.set(c.id, c);
          });
          prev.forEach((c) => {
            if (c.id && !map.has(c.id)) map.set(c.id, c);
          });
          return Array.from(map.values());
        });
      }
    } catch (err) {
      console.warn('Supabase initial sync info:', err);
    } finally {
      setIsSupabaseSyncing(false);
    }
  };

  // Background sync on mount
  useEffect(() => {
    syncWithSupabase();
  }, []);

  // Toast Helpers
  const addToast = (type: 'success' | 'info' | 'error', title: string, message?: string) => {
    const id = 'toast-' + Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Navigation Helper
  const navigate = (page: PageView, params?: { slug?: string; category?: string }) => {
    setCurrentPage(page);
    if (params?.slug) setSelectedSlug(params.slug);
    if (params?.category !== undefined) setActiveCategoryFilter(params.category);
    // Scroll window to top cleanly
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart Calculations
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => {
    const effectivePrice = item.product.salePrice ?? item.product.price;
    return sum + effectivePrice * item.quantity;
  }, 0);

  // Free shipping throughout Pakistan on luxury orders above Rs. 15,000, otherwise nominal standard Rs. 500
  const cartShippingFee = cartSubtotal > 15000 || cartSubtotal === 0 ? 0 : 500;
  const cartTotal = cartSubtotal + cartShippingFee;

  // Cart Actions
  const addToCart = (product: Product, quantity = 1, variant?: Record<string, string>) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          JSON.stringify(item.selectedVariant || {}) === JSON.stringify(variant || {})
      );

      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity,
        };
        return next;
      } else {
        return [...prev, { product, quantity, selectedVariant: variant }];
      }
    });

    addToast('success', 'Added to Luxury Bag', `${product.name} (Qty: ${quantity})`);
    setIsCartDrawerOpen(true);
  };

  const removeFromCart = (productId: string, variantKey?: string) => {
    setCart((prev) =>
      prev.filter((item) => {
        if (item.product.id !== productId) return true;
        if (!variantKey) return false;
        return JSON.stringify(item.selectedVariant || {}) !== variantKey;
      })
    );
    addToast('info', 'Item Removed', 'Product removed from your shopping bag');
  };

  const updateCartQuantity = (productId: string, quantity: number, variantKey?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, variantKey);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        const matchesProduct = item.product.id === productId;
        const matchesVariant =
          !variantKey || JSON.stringify(item.selectedVariant || {}) === variantKey;
        if (matchesProduct && matchesVariant) {
          return { ...item, quantity };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  // Wishlist Actions
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      const product = products.find((p) => p.id === productId);
      if (exists) {
        addToast('info', 'Removed from Wishlist', product?.name);
        return prev.filter((id) => id !== productId);
      } else {
        addToast('success', 'Saved to Wishlist', product?.name);
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Catalog Getters & Management
  const getProductBySlug = (slug: string) => products.find((p) => p.slug === slug);
  const getProductById = (id: string) => products.find((p) => p.id === id);

  const addProduct = (newProd: Partial<Product>): Product => {
    const slug =
      newProd.slug ||
      (newProd.name
        ? newProd.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '')
        : 'product-' + Date.now());

    const created: Product = {
      id: 'prod-' + Date.now(),
      name: newProd.name || 'Untitled Timepiece',
      slug,
      category: newProd.category || 'watches',
      categoryName:
        categories.find((c) => c.slug === newProd.category)?.name || 'Watches',
      brand: newProd.brand || 'STORIUM Haute Horlogerie',
      price: Number(newProd.price) || 25000,
      salePrice: newProd.salePrice ? Number(newProd.salePrice) : undefined,
      sku: newProd.sku || `STM-${Math.floor(1000 + Math.random() * 9000)}`,
      stockQuantity: Number(newProd.stockQuantity) || 10,
      thumbnail:
        newProd.thumbnail ||
        newProd.productImages?.[0] ||
        'https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1000&auto=format&fit=crop',
      productImages:
        newProd.productImages && newProd.productImages.length > 0
          ? newProd.productImages
          : [
              'https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1200&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop',
            ],
      description: newProd.description || 'Precision engineered STORIUM timepiece.',
      shortDescription:
        newProd.shortDescription || 'Luxury handcrafted timepiece with sapphire crystal.',
      specifications: newProd.specifications || {
        Movement: 'Japanese Precision Quartz / Mechanical',
        'Case Material': '316L Surgical Stainless Steel',
        Glass: 'Scratch-Resistant Sapphire Crystal',
        'Water Resistance': '5 ATM / 50M',
      },
      features: newProd.features || [
        '316L Surgical-Grade Stainless Steel',
        'Scratch-Resistant Sapphire Crystal',
        'High-Precision Calibre Mechanism',
      ],
      variants: newProd.variants,
      featured: Boolean(newProd.featured),
      isNew: Boolean(newProd.isNew),
      availability: newProd.availability || 'in_stock',
      tags: newProd.tags || ['Luxury', 'STORIUM'],
      seoTitle: newProd.seoTitle || `${newProd.name} | STORIUM Pakistan`,
      seoDescription:
        newProd.seoDescription ||
        `Purchase ${newProd.name} at STORIUM. Free insured nationwide delivery.`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProducts((prev) => [created, ...prev]);
    addToast('success', 'Product Published', `${created.name} is now live in showroom.`);
    return created;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p))
    );
    addToast('success', 'Product Updated', 'Changes saved successfully.');
  };

  const deleteProduct = (id: string) => {
    const p = products.find((x) => x.id === id);
    setProducts((prev) => prev.filter((item) => item.id !== id));
    addToast('info', 'Product Removed', p?.name);
  };

  const addCategory = (cat: Partial<Category>) => {
    const slug =
      cat.slug ||
      (cat.name
        ? cat.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '')
        : 'category-' + Date.now());

    const created: Category = {
      id: 'cat-' + Date.now(),
      name: cat.name || 'New Category',
      slug,
      description: cat.description || 'Curated luxury collection.',
      image:
        cat.image ||
        'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop',
      itemCount: 0,
    };
    setCategories((prev) => [...prev, created]);
    addToast('success', 'Category Created', created.name);
  };

  // Orders
  const createOrder = async (
    orderData: Omit<Order, 'id' | 'orderNumber' | 'date'>
  ): Promise<Order> => {
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const newOrder: Order = {
      ...orderData,
      id: 'ord-' + Date.now(),
      orderNumber: `STM-PK-${randomNum}`,
      date: new Date().toISOString(),
      orderStatus: 'Pending',
      trackingNumber: `TCS-${Math.floor(10000000 + Math.random() * 90000000)}-${orderData.customer.city.substring(0, 3).toUpperCase()}`,
      supabaseSynced: false,
    };

    // Attempt direct cloud sync with Supabase
    try {
      const syncResult = await saveOrderToSupabase(newOrder);
      if (syncResult.success) {
        newOrder.supabaseSynced = true;
        addToast(
          'success',
          'Order Confirmed & Synced',
          `Order #${newOrder.orderNumber} successfully recorded in Supabase.`
        );
      } else if (syncResult.isTableMissing) {
        console.info('Supabase orders table not yet initialized. Saved to local orders.');
        addToast(
          'success',
          'Order Confirmed',
          `Order #${newOrder.orderNumber} placed. (Supabase orders table awaiting SQL schema setup).`
        );
      } else {
        addToast(
          'success',
          'Order Confirmed',
          `Order #${newOrder.orderNumber} successfully placed.`
        );
      }
    } catch (err) {
      console.warn('Supabase order insert error:', err);
      addToast(
        'success',
        'Order Confirmed',
        `Order #${newOrder.orderNumber} placed successfully.`
      );
    }

    setOrders((prev) => [newOrder, ...prev]);
    setLastPlacedOrder(newOrder);
    clearCart();
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: Order['orderStatus']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, orderStatus: status } : ord))
    );
    addToast('info', 'Order Status Updated', `Order marked as ${status}.`);
  };

  // Concierge / Contact Inquiries
  const submitContactInquiry = async (
    inquiryData: Omit<ContactInquiry, 'id' | 'createdAt' | 'status'>
  ): Promise<{ success: boolean; supabaseSynced: boolean; message?: string }> => {
    const newInquiry: ContactInquiry = {
      ...inquiryData,
      id: 'inq-' + Date.now(),
      createdAt: new Date().toISOString(),
      status: 'new',
      supabaseSynced: false,
    };

    let supabaseSynced = false;
    let feedbackMessage = 'Inquiry logged with our luxury concierge.';

    try {
      const syncResult = await saveContactToSupabase(newInquiry);
      if (syncResult.success) {
        supabaseSynced = true;
        newInquiry.supabaseSynced = true;
        feedbackMessage = 'Your inquiry has been recorded and saved directly to Supabase.';
        addToast('success', 'Inquiry Dispatched & Synced', feedbackMessage);
      } else if (syncResult.isTableMissing) {
        feedbackMessage = 'Inquiry logged locally. (Supabase contacts table awaiting SQL schema setup).';
        addToast('info', 'Inquiry Registered', feedbackMessage);
      } else {
        feedbackMessage = 'Our luxury concierge will respond within 4 hours.';
        addToast('success', 'Inquiry Dispatched', feedbackMessage);
      }
    } catch (err) {
      console.warn('Supabase contact submission error:', err);
      addToast('success', 'Inquiry Dispatched', 'Our luxury concierge will respond promptly.');
    }

    setInquiries((prev) => [newInquiry, ...prev]);
    return { success: true, supabaseSynced, message: feedbackMessage };
  };

  // User / Auth
  const loginUser = (email: string, fullName = 'Valued Client', phone = '+92 300 1234567') => {
    const user: CustomerUser = {
      id: 'cust-' + Date.now(),
      fullName,
      email,
      phone,
      city: 'Karachi',
      address: 'Clifton Block 4',
      createdAt: new Date().toISOString(),
    };
    setCurrentUser(user);
    addToast('success', 'Welcome Back', `Logged in as ${fullName}`);
  };

  const logoutUser = () => {
    setCurrentUser(null);
    addToast('info', 'Logged Out', 'You have been safely signed out.');
  };

  const updateUserProfile = (updates: Partial<CustomerUser>) => {
    if (!currentUser) return;
    setCurrentUser((prev) => (prev ? { ...prev, ...updates } : null));
    addToast('success', 'Profile Updated', 'Your details have been refreshed.');
  };

  return (
    <StoreContext.Provider
      value={{
        currentPage,
        selectedSlug,
        activeCategoryFilter,
        navigate,

        products,
        categories,
        getProductBySlug,
        getProductById,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,

        cart,
        cartCount,
        cartSubtotal,
        cartShippingFee,
        cartTotal,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartDrawerOpen,
        openCartDrawer: () => setIsCartDrawerOpen(true),
        closeCartDrawer: () => setIsCartDrawerOpen(false),

        wishlist,
        toggleWishlist,
        isInWishlist,

        orders,
        createOrder,
        updateOrderStatus,
        lastPlacedOrder,

        inquiries,
        submitContactInquiry,
        isSupabaseSyncing,
        syncWithSupabase,

        currentUser,
        loginUser,
        logoutUser,
        updateUserProfile,

        isSearchOpen,
        openSearch: () => setIsSearchOpen(true),
        closeSearch: () => setIsSearchOpen(false),
        searchQuery,
        setSearchQuery,

        quickViewProduct,
        openQuickView: (p) => setQuickViewProduct(p),
        closeQuickView: () => setQuickViewProduct(null),

        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
